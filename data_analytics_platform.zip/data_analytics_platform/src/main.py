import boto3
from flask import Flask, request, jsonify
from infrastructure.models.DataModel import DataModel
from domain.services.DataService import