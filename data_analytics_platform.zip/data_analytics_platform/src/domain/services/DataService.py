class DataService:
    def __init__(self, data_repository):
        self.data_repository = data_repository

    def add_data_record(self, data_record):
        self.data_repository.save(data_record)

    def get_data_record(self, id):
        return self.data_repository.find_by_id(id)

    def get_all_data_records(self):
        return self.data_repository.find_all()

    def delete_data_record(self, id):
        self.data_repository.delete(id)