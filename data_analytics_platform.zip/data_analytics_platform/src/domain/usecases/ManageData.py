from domain.entities.DataRecord import DataRecord
from domain.services.DataService import DataService

class ManageData:
    def __init__(self, data_service):
        self.data_service = data_service

    def create_data_record(self, id, value, timestamp):
        data_record = DataRecord(id, value, timestamp)
        self.data_service.add_data_record(data_record)

    def view_data_record(self, id):
        return self.data_service.get_data_record(id)

    def view_all_data_records(self):
        return self.data_service.get_all_data_records()

    def remove_data_record(self, id):
        self.data_service.delete_data_record(id)