class DataAnalysis:
    def __init__(self, id, data_id, analysis_result, timestamp):
        self.id = id
        self.data_id = data_id
        self.analysis_result = analysis_result
        self.timestamp = timestamp