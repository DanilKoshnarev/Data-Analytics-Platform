from domain.usecases.ManageData import ManageData
from domain.entities.DataRecord import DataRecord

class DataController:
    def __init__(self, manage_data):
        self.manage_data = manage_data

    def add_data_record(self, id, value, timestamp):
        self.manage_data.create_data_record(id, value, timestamp)

    def get_data_record(self, id):
        return self.manage_data.view_data_record(id)

    def get_all_data_records(self):
        return self.manage_data.view_all_data_records()

    def delete_data_record(self, id):
        self.manage_data.remove_data_record(id)