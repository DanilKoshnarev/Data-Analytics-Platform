from flask import Flask, request, jsonify
from infrastructure.models.DataModel import DataModel
from domain.services.DataService import DataService
from domain.usecases.ManageData import ManageData
from infrastructure.controllers.DataController import DataController

app = Flask(__name__)

data_repository = DataModel()
data_service = DataService(data_repository)
manage_data = ManageData(data_service)
data_controller = DataController(manage_data)

@app.route('/data', methods=['POST'])
def add_data_record():
    data = request.json
    data_controller.add_data_record(data['id'], data['value'], data['timestamp'])
    return jsonify({'message': 'Data record created successfully!'})

@app.route('/data', methods=['GET'])
def get_data_record():
    data_id = request.args.get('id')
    data_record = data_controller.get_data_record(data_id)
    if data_record:
        return jsonify(data_record.__dict__)
    return jsonify({'message': 'Data record not found!'}), 404

@app.route('/data', methods=['DELETE'])
def delete_data_record():
    data_id = request.args.get('id')
    data_controller.delete_data_record(data_id)
    return jsonify({'message': 'Data record deleted successfully!'})

if __name__ == '__main__':
    app.run(debug=True)