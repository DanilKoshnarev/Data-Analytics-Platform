from domain.entities.DataRecord import DataRecord
from domain.repositories.DataRepository import DataRepository

class DataModel(DataRepository):
    def __init__(self):
        self.data_records = []

    def save(self, data_record):
        self.data_records.append(data_record)

    def find_by_id(self, id):
        for record in self.data_records:
            if record.id == id:
                return record
        return None

    def find_all(self):
        return self.data_records

    def delete(self, id):
        self.data_records = [record for record in self.data_records if record.id != id]