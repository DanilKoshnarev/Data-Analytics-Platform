import json
from infrastructure.models.DataModel import DataModel
from domain.services.DataService import DataService
from domain.usecases.ManageData import ManageData
from infrastructure.controllers.DataController import DataController

def lambda_handler(event, context):
    data_repository = DataModel()
    data_service = DataService(data_repository)
    manage_data = ManageData(data_service)
    data_controller = DataController(manage_data)

    if event['httpMethod'] == 'POST':
        data = json.loads(event['body'])
        data_controller.add_data_record(data['id'], data['value'], data['timestamp'])
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Data record created successfully!'})
        }

    elif event['httpMethod'] == 'GET':
        data_id = event['queryStringParameters']['id']
        data_record = data_controller.get_data_record(data_id)
        if data_record:
            return {
                'statusCode': 200,
                'body': json.dumps(data_record.__dict__)
            }
        else:
            return {
                'statusCode': 404,
                'body': json.dumps({'message': 'Data record not found!'})
            }

    elif event['httpMethod'] == 'DELETE':
        data_id = event['queryStringParameters']['id']
        data_controller.delete_data_record(data_id)
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Data record deleted successfully!'})
        }

    return {
        'statusCode': 400,
        'body': json.dumps({'message': 'Invalid request!'})
    }